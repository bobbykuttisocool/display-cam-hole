# GREATNESS (Android v12 — Full Camera Punch-Hole & Display Cutout Safe Areas)

## Build APK on GitHub
1. Upload `GREATNESS-v12.zip` directly to your GitHub repo root.
2. Update `.github/workflows/build-apk.yml` so it unpacks `GREATNESS-v12*.zip`.
3. Wait ~2 minutes in **Actions**, download `app-debug.apk` from **Artifacts**, and install.
