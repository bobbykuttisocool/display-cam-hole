package com.pulse.music

import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import org.json.JSONObject

object PlaybackSkipBus {
    @Volatile
    var onSkipNext: (() -> Unit)? = null

    @Volatile
    var onSkipPrev: (() -> Unit)? = null
}

object AudioFxBus {
    private val lock = Any()
    private var sessionId: Int = 0
    private var bassBoost: BassBoost? = null
    private var equalizer: Equalizer? = null

    @Volatile
    var currentPreset: String = "flat"
        private set

    @Volatile
    var currentBassPercent: Int = 0
        private set

    fun attachSession(newSessionId: Int) {
        synchronized(lock) {
            if (newSessionId <= 0) return@synchronized
            if (newSessionId == sessionId && (bassBoost != null || equalizer != null)) {
                applyInternal()
                return@synchronized
            }
            releaseInternal()
            sessionId = newSessionId
            try {
                bassBoost = BassBoost(0, newSessionId)
            } catch (_: Exception) {
                bassBoost = null
            }
            try {
                equalizer = Equalizer(0, newSessionId)
            } catch (_: Exception) {
                equalizer = null
            }
            applyInternal()
        }
    }

    fun apply(preset: String, bassPercent: Int) {
        synchronized(lock) {
            currentPreset = preset.lowercase()
            currentBassPercent = bassPercent.coerceIn(0, 100)
            applyInternal()
        }
    }

    fun getStateJson(): String {
        return JSONObject().apply {
            put("preset", currentPreset)
            put("bass", currentBassPercent)
            put("ready", sessionId > 0)
        }.toString()
    }

    private fun applyInternal() {
        try {
            bassBoost?.let { bb ->
                val targetStrength = (currentBassPercent * 10).coerceIn(0, 1000)
                bb.enabled = targetStrength > 0
                if (bb.strengthSupported) {
                    bb.setStrength(targetStrength.toShort())
                }
            }
        } catch (_: Exception) {
        }

        try {
            equalizer?.let { eq ->
                val bands = eq.numberOfBands.toInt()
                if (bands <= 0) return
                val range = eq.bandLevelRange
                val minLvl = range[0].toInt()
                val maxLvl = range[1].toInt()

                if (currentPreset == "flat") {
                    for (b in 0 until bands) {
                        eq.setBandLevel(b.toShort(), 0)
                    }
                    eq.enabled = false
                    return
                }

                val curve = when (currentPreset) {
                    "bass"  -> floatArrayOf(0.85f, 0.50f, 0.05f, 0.15f, 0.25f)
                    "vocal" -> floatArrayOf(-0.20f, 0.15f, 0.70f, 0.55f, 0.15f)
                    "club"  -> floatArrayOf(0.70f, 0.35f, -0.10f, 0.40f, 0.70f)
                    "late"  -> floatArrayOf(-0.35f, 0.10f, 0.30f, -0.10f, -0.40f)
                    else    -> floatArrayOf(0f, 0f, 0f, 0f, 0f)
                }

                eq.enabled = true
                for (b in 0 until bands) {
                    val normPos = if (bands == 1) 0f else (b.toFloat() / (bands - 1)) * (curve.size - 1)
                    val lo = normPos.toInt().coerceIn(0, curve.size - 1)
                    val hi = (lo + 1).coerceIn(0, curve.size - 1)
                    val frac = normPos - lo
                    val factor = curve[lo] + (curve[hi] - curve[lo]) * frac
                    val target = if (factor >= 0f) {
                        (factor * maxLvl * 0.65f).toInt()
                    } else {
                        (factor * -minLvl * 0.55f).toInt()
                    }.coerceIn(minLvl, maxLvl)
                    eq.setBandLevel(b.toShort(), target.toShort())
                }
            }
        } catch (_: Exception) {
        }
    }

    fun release() {
        synchronized(lock) {
            releaseInternal()
            sessionId = 0
        }
    }

    private fun releaseInternal() {
        try { bassBoost?.release() } catch (_: Exception) {}
        try { equalizer?.release() } catch (_: Exception) {}
        bassBoost = null
        equalizer = null
    }
}

@OptIn(UnstableApi::class)
class PulsePlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()

        val okHttpFactory = OkHttpDataSource.Factory(PulseDownloader.httpClient)
            .setUserAgent(PulseDownloader.USER_AGENT)
        val dataSourceFactory = DefaultDataSource.Factory(this, okHttpFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(dataSourceFactory)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val exoPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        exoPlayer.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioSessionIdChanged(
                eventTime: AnalyticsListener.EventTime,
                audioSessionId: Int
            ) {
                AudioFxBus.attachSession(audioSessionId)
            }
        })
        if (exoPlayer.audioSessionId > 0) {
            AudioFxBus.attachSession(exoPlayer.audioSessionId)
        }

        val queueAwarePlayer = object : ForwardingPlayer(exoPlayer) {
            override fun getAvailableCommands(): Player.Commands {
                return super.getAvailableCommands().buildUpon()
                    .add(Player.COMMAND_SEEK_TO_NEXT)
                    .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                    .build()
            }

            override fun isCommandAvailable(command: Int): Boolean {
                return when (command) {
                    Player.COMMAND_SEEK_TO_NEXT,
                    Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
                    Player.COMMAND_SEEK_TO_PREVIOUS,
                    Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM -> true
                    else -> super.isCommandAvailable(command)
                }
            }

            override fun seekToNext() {
                PlaybackSkipBus.onSkipNext?.invoke()
            }

            override fun seekToNextMediaItem() {
                PlaybackSkipBus.onSkipNext?.invoke()
            }

            override fun seekToPrevious() {
                if (currentPosition > 4000L) {
                    seekTo(0L)
                } else {
                    PlaybackSkipBus.onSkipPrev?.invoke()
                }
            }

            override fun seekToPreviousMediaItem() {
                PlaybackSkipBus.onSkipPrev?.invoke()
            }
        }

        mediaSession = MediaSession.Builder(this, queueAwarePlayer).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0 || player.playbackState == Player.STATE_ENDED) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        AudioFxBus.release()
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
