package com.pulse.music

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import okhttp3.Request
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

object CoverThemeExtractor {
    private const val MAX_CACHE_ENTRIES = 64
    private val cacheLock = Any()
    private val lruCache = object : LinkedHashMap<String, String>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > MAX_CACHE_ENTRIES
        }
    }

    fun extractThemeJson(imageUrl: String): String {
        val url = imageUrl.trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            return defaultThemeJson()
        }
        synchronized(cacheLock) {
            lruCache[url]?.let { return it }
        }

        return try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", PulseDownloader.USER_AGENT)
                .build()

            val bytes = PulseDownloader.httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return defaultThemeJson()
                resp.body?.bytes() ?: return defaultThemeJson()
            }
            if (bytes.isEmpty()) return defaultThemeJson()

            // First decode bounds only so oversized artwork never spikes heap RAM
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            val minDim = min(bounds.outWidth, bounds.outHeight)
            while (minDim > 0 && (minDim / sample) > 96) {
                sample *= 2
            }

            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            val rawBmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                ?: return defaultThemeJson()

            val scaled = Bitmap.createScaledBitmap(rawBmp, 24, 24, true)
            if (scaled != rawBmp) rawBmp.recycle()

            val result = computeFlatPalette(scaled)
            scaled.recycle()

            synchronized(cacheLock) {
                lruCache[url] = result
            }
            result
        } catch (_: Exception) {
            defaultThemeJson()
        }
    }

    private fun computeFlatPalette(bmp: Bitmap): String {
        val rSum = FloatArray(36)
        val gSum = FloatArray(36)
        val bSum = FloatArray(36)
        val wSum = FloatArray(36)
        val hsv = FloatArray(3)

        var fallbackR = 0f
        var fallbackG = 0f
        var fallbackB = 0f
        var fallbackCount = 0

        val w = bmp.width
        val h = bmp.height
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)

        val xStart = 2.coerceAtMost(w - 1)
        val xEnd = (w - 2).coerceAtLeast(xStart + 1)
        val yStart = 4.coerceAtMost(h - 1)
        val yEnd = (h - 4).coerceAtLeast(yStart + 1)

        for (y in yStart until yEnd) {
            val rowOffset = y * w
            for (x in xStart until xEnd) {
                val px = pixels[rowOffset + x]
                val r = Color.red(px)
                val g = Color.green(px)
                val b = Color.blue(px)
                Color.RGBToHSV(r, g, b, hsv)
                val sat = hsv[1]
                val value = hsv[2]

                if (value > 0.08f && value < 0.96f) {
                    fallbackR += r
                    fallbackG += g
                    fallbackB += b
                    fallbackCount++
                }

                if (sat > 0.16f && value > 0.14f && value < 0.94f) {
                    val bin = ((hsv[0] / 10f).toInt()).coerceIn(0, 35)
                    val weight = (sat * sat * 2.2f + 0.35f) * (1f - kotlin.math.abs(value - 0.52f))
                    rSum[bin] += r * weight
                    gSum[bin] += g * weight
                    bSum[bin] += b * weight
                    wSum[bin] += weight
                }
            }
        }

        var bestBin = -1
        var bestWeight = 0f
        for (i in 0 until 36) {
            if (wSum[i] > bestWeight) {
                bestWeight = wSum[i]
                bestBin = i
            }
        }

        val domR: Int
        val domG: Int
        val domB: Int
        if (bestBin >= 0 && bestWeight > 0f) {
            domR = (rSum[bestBin] / bestWeight).toInt().coerceIn(0, 255)
            domG = (gSum[bestBin] / bestWeight).toInt().coerceIn(0, 255)
            domB = (bSum[bestBin] / bestWeight).toInt().coerceIn(0, 255)
        } else if (fallbackCount > 0) {
            domR = (fallbackR / fallbackCount).toInt().coerceIn(0, 255)
            domG = (fallbackG / fallbackCount).toInt().coerceIn(0, 255)
            domB = (fallbackB / fallbackCount).toInt().coerceIn(0, 255)
        } else {
            return defaultThemeJson()
        }

        Color.RGBToHSV(domR, domG, domB, hsv)
        val hue = hsv[0]
        val baseSat = hsv[1]

        val bgHsv = floatArrayOf(hue, min(0.68f, max(0.28f, baseSat * 0.85f)), 0.25f)
        val surfaceHsv = floatArrayOf(hue, min(0.64f, max(0.24f, baseSat * 0.80f)), 0.33f)
        val accentHsv = floatArrayOf(hue, min(0.85f, max(0.45f, baseSat)), 0.96f)

        return JSONObject().apply {
            put("bg", colorToHex(Color.HSVToColor(bgHsv)))
            put("surface", colorToHex(Color.HSVToColor(surfaceHsv)))
            put("accent", colorToHex(Color.HSVToColor(accentHsv)))
        }.toString()
    }

    private fun colorToHex(color: Int): String = String.format("#%06X", 0xFFFFFF and color)

    private fun defaultThemeJson(): String = JSONObject().apply {
        put("bg", "#141418")
        put("surface", "#1E1E26")
        put("accent", "#FF375F")
    }.toString()
}
