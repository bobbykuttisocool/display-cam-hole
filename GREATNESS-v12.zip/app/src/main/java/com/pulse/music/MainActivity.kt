package com.pulse.music

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "PulseMain"
    }

    private lateinit var rootContainer: FrameLayout
    private lateinit var webView: WebView
    private var lastSafeTopDp: Float = 0f
    private var lastSafeRightDp: Float = 0f
    private var lastSafeBottomDp: Float = 0f
    private var lastSafeLeftDp: Float = 0f
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private val uiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val tickerHandler = Handler(Looper.getMainLooper())

    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private var isForeground: Boolean = false
    private var activePlayJob: Job? = null
    private var activeThemeJob: Job? = null
    private var activeSearchJob: Job? = null
    private var activeImportJob: Job? = null
    private val activeDownloads = ConcurrentHashMap.newKeySet<String>()

    private var activeTrackMeta: JSONObject? = null
    private var currentCandidates: List<YouTubeEngine.StreamCandidate> = emptyList()
    private var candidateIndex: Int = 0
    private var retriedFreshExtraction: Boolean = false
    private var pendingResumePosMs: Long = 0L

    private val notificationPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private fun pushPlaybackState(snap: Boolean = false) {
        val ctrl = mediaController ?: return
        val posSec = ctrl.currentPosition.coerceAtLeast(0L) / 1000.0
        val durSec = (ctrl.duration.takeIf { it > 0 } ?: 0L) / 1000.0
        val playing = ctrl.isPlaying
        emitJs("window.__pulseOnProgress && window.__pulseOnProgress($posSec, $durSec, $playing, $snap)")
    }

    private val progressTicker = object : Runnable {
        override fun run() {
            val ctrl = mediaController
            if (isForeground && ctrl != null && ctrl.isPlaying) {
                pushPlaybackState(snap = false)
                tickerHandler.postDelayed(this, 200L)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pushSafeAreaToWeb()
                    ViewCompat.requestApplyInsets(rootContainer)
                }
            }
            addJavascriptInterface(PulseJsBridge(), "PulseNative")
        }

        rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }

        val safeTypes = WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        ViewCompat.setOnApplyWindowInsetsListener(rootContainer) { view, windowInsets ->
            val safe = windowInsets.getInsets(safeTypes)
            val ime = windowInsets.getInsets(WindowInsetsCompat.Type.ime())
            val density = resources.displayMetrics.density.coerceAtLeast(1f)

            lastSafeTopDp = safe.top / density
            lastSafeRightDp = safe.right / density
            lastSafeBottomDp = safe.bottom / density
            lastSafeLeftDp = safe.left / density

            // Only pad container bottom when keyboard (IME) is open so inputs stay visible
            val imeExtraBottom = (ime.bottom - safe.bottom).coerceAtLeast(0)
            view.setPadding(0, 0, 0, imeExtraBottom)

            pushSafeAreaToWeb()

            // Zero out handled systemBars + displayCutout insets so modern WebView won't double-pad
            WindowInsetsCompat.Builder(windowInsets)
                .setInsets(safeTypes, Insets.NONE)
                .setInsets(WindowInsetsCompat.Type.ime(), Insets.NONE)
                .build()
        }

        setContentView(rootContainer)
        ViewCompat.requestApplyInsets(rootContainer)
        webView.loadUrl("file:///android_asset/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(window.__pulseHandleBack && window.__pulseHandleBack()) ? 'handled' : 'exit'"
                ) { result ->
                    if (result == null || !result.contains("handled")) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        PlaybackSkipBus.onSkipNext = {
            emitJs("window.__pulseSkipNext && window.__pulseSkipNext()")
        }
        PlaybackSkipBus.onSkipPrev = {
            emitJs("window.__pulseSkipPrev && window.__pulseSkipPrev()")
        }

        connectMediaService()
    }

    override fun onStart() {
        super.onStart()
        isForeground = true
        pushPlaybackState(snap = true)
        tickerHandler.removeCallbacks(progressTicker)
        if (mediaController?.isPlaying == true) {
            tickerHandler.post(progressTicker)
        }
    }

    override fun onStop() {
        isForeground = false
        tickerHandler.removeCallbacks(progressTicker)
        super.onStop()
    }

    private fun connectMediaService() {
        val token = SessionToken(this, ComponentName(this, PulsePlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                val ctrl = controllerFuture?.get() ?: return@addListener
                mediaController = ctrl
                ctrl.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        pushPlaybackState(snap = true)
                        tickerHandler.removeCallbacks(progressTicker)
                        if (isForeground && isPlaying) tickerHandler.post(progressTicker)
                    }

                    override fun onPositionDiscontinuity(
                        oldPosition: Player.PositionInfo,
                        newPosition: Player.PositionInfo,
                        reason: Int
                    ) {
                        pushPlaybackState(snap = true)
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            pushPlaybackState(snap = true)
                        } else if (playbackState == Player.STATE_ENDED) {
                            emitJs("window.__pulseOnEnded && window.__pulseOnEnded()")
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        Log.w(TAG, "ExoPlayer error (${error.errorCodeName}): ${error.message}")
                        val savedPos = ctrl.currentPosition.coerceAtLeast(0L)
                        if (savedPos > 2000L) pendingResumePosMs = savedPos
                        tryNextCandidateOrReExtract(error.message ?: error.errorCodeName)
                    }
                })
                if (isForeground) pushPlaybackState(snap = true)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to connect MediaController", e)
                emitJs("window.__pulseOnError && window.__pulseOnError('Audio service unavailable')")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun tryNextCandidateOrReExtract(reason: String) {
        val nextIdx = candidateIndex + 1
        if (nextIdx < currentCandidates.size) {
            candidateIndex = nextIdx
            val next = currentCandidates[candidateIndex]
            emitJs("window.__pulseOnStatus && window.__pulseOnStatus(${safeJsonString("Switching stream -> ${next.label}")})")
            playCurrentCandidate()
            return
        }

        val trackObj = activeTrackMeta
        if (!retriedFreshExtraction && trackObj != null) {
            retriedFreshExtraction = true
            emitJs("window.__pulseOnStatus && window.__pulseOnStatus('Refreshing stream...')")
            startTrackPlayback(trackObj, forceRefresh = true, resumeMs = pendingResumePosMs)
            return
        }

        pendingResumePosMs = 0L
        emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString("Playback error: $reason")})")
    }

    private fun extractCoverThemeAsync(trackId: String, coverUrl: String) {
        activeThemeJob?.cancel()
        if (!coverUrl.startsWith("http://") && !coverUrl.startsWith("https://")) return
        activeThemeJob = uiScope.launch(Dispatchers.IO) {
            val themeJson = CoverThemeExtractor.extractThemeJson(coverUrl)
            emitJs("window.__pulseOnCoverTheme && window.__pulseOnCoverTheme(${safeJsonString(trackId)}, $themeJson)")
        }
    }

    private fun startTrackPlayback(trackObj: JSONObject, forceRefresh: Boolean, resumeMs: Long = 0L) {
        activePlayJob?.cancel()
        activeTrackMeta = trackObj
        pendingResumePosMs = resumeMs
        if (!forceRefresh) retriedFreshExtraction = false

        val id = trackObj.getString("id")
        val cover = trackObj.optString("cover", "")
        extractCoverThemeAsync(id, cover)

        activePlayJob = uiScope.launch(Dispatchers.IO) {
            try {
                emitJs("window.__pulseOnStatus && window.__pulseOnStatus('Loading audio stream...')")

                var waitMs = 0
                while (mediaController == null && waitMs < 4000) {
                    delay(100)
                    waitMs += 100
                }
                if (mediaController == null) {
                    throw IllegalStateException("Audio service did not start in time")
                }

                val resolved = YouTubeEngine.resolvePlayback(
                    context = this@MainActivity,
                    videoIdOrUrl = id,
                    forceRefresh = forceRefresh
                )

                launch(Dispatchers.Main) {
                    currentCandidates = resolved.candidates
                    candidateIndex = 0
                    playCurrentCandidate()
                    val statusJson = YouTubeEngine.getStatusJson()
                    val note = when {
                        resolved.isOffline -> "Playing offline"
                        resolved.healed -> "Refreshed YouTube auth"
                        else -> ""
                    }
                    emitJs("window.__pulseOnTrackReady && window.__pulseOnTrackReady($statusJson, ${safeJsonString(note)})")
                }
            } catch (_: CancellationException) {
                // Newer track tapped
            } catch (e: Exception) {
                Log.e(TAG, "Playback resolution failed", e)
                emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString(e.message ?: "Could not load track")})")
            }
        }
    }

    private fun playCurrentCandidate() {
        val ctrl = mediaController ?: return
        val trackObj = activeTrackMeta ?: return
        val cand = currentCandidates.getOrNull(candidateIndex) ?: return

        val title = trackObj.optString("title", "Unknown")
        val artist = trackObj.optString("artist", "YouTube")
        val cover = trackObj.optString("cover", "")

        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setArtworkUri(if (cover.isNotBlank()) Uri.parse(cover) else null)
            .build()

        val builder = MediaItem.Builder()
            .setUri(cand.url)
            .setMediaMetadata(metadata)

        if (cand.isHls) {
            builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }

        val startAt = pendingResumePosMs
        pendingResumePosMs = 0L
        ctrl.setMediaItem(builder.build(), startAt)
        ctrl.prepare()
        ctrl.play()
    }

    private fun pushSafeAreaToWeb() {
        val t = String.format(java.util.Locale.US, "%.2f", lastSafeTopDp)
        val r = String.format(java.util.Locale.US, "%.2f", lastSafeRightDp)
        val b = String.format(java.util.Locale.US, "%.2f", lastSafeBottomDp)
        val l = String.format(java.util.Locale.US, "%.2f", lastSafeLeftDp)
        emitJs("window.__pulseOnSafeArea && window.__pulseOnSafeArea($t,$r,$b,$l)")
    }

    private fun emitJs(script: String) {
        runOnUiThread {
            if (!isDestroyed && !isFinishing) {
                webView.evaluateJavascript(script, null)
            }
        }
    }

    private fun safeJsonString(value: String): String = JSONObject.quote(value)

    inner class PulseJsBridge {

        @JavascriptInterface
        fun getVolumePercent(): Int {
            return try {
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, maxVol)
                ((curVol * 100f) / maxVol).roundToInt()
            } catch (_: Exception) {
                70
            }
        }

        @JavascriptInterface
        fun stepVolume(delta: Int): Int {
            return try {
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                val step = max(1, (maxVol / 20f).roundToInt())
                val nextVol = (curVol + delta * step).coerceIn(0, maxVol)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                ((nextVol * 100f) / maxVol).roundToInt()
            } catch (_: Exception) {
                70
            }
        }

        @JavascriptInterface
        fun haptic(style: String) {
            try {
                val vib = vibrator ?: return
                if (!vib.hasVibrator()) return

                val durationMs = when (style) {
                    "click" -> 22L
                    "tick" -> 10L
                    else -> 7L
                }
                val amplitude = when (style) {
                    "click" -> 225
                    "tick" -> 145
                    else -> 105
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val amp = if (vib.hasAmplitudeControl()) amplitude else VibrationEffect.DEFAULT_AMPLITUDE
                    vib.vibrate(VibrationEffect.createOneShot(durationMs, amp))
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(durationMs)
                }
            } catch (_: Exception) {
            }
        }

        @JavascriptInterface
        fun setSystemTheme(bgHex: String, isLight: Boolean) {
            runOnUiThread {
                try {
                    val color = Color.parseColor(bgHex)
                    window.decorView.setBackgroundColor(color)
                    rootContainer.setBackgroundColor(color)
                    webView.setBackgroundColor(color)
                    @Suppress("DEPRECATION")
                    window.statusBarColor = Color.TRANSPARENT
                    @Suppress("DEPRECATION")
                    window.navigationBarColor = Color.TRANSPARENT
                    val insetsCtrl = WindowCompat.getInsetsController(window, window.decorView)
                    insetsCtrl.isAppearanceLightStatusBars = isLight
                    insetsCtrl.isAppearanceLightNavigationBars = isLight
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun setStatusBarLight(isLight: Boolean) {
            runOnUiThread {
                try {
                    val insetsCtrl = WindowCompat.getInsetsController(window, window.decorView)
                    insetsCtrl.isAppearanceLightStatusBars = isLight
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun getAuthStatus(): String = YouTubeEngine.getStatusJson()

        @JavascriptInterface
        fun forceRefreshAuth() {
            uiScope.launch(Dispatchers.IO) {
                val msg = YouTubeEngine.resetExtractorCache()
                val statusJson = YouTubeEngine.getStatusJson()
                emitJs("window.__pulseOnAuthUpdated && window.__pulseOnAuthUpdated($statusJson, ${safeJsonString(msg)})")
            }
        }


        @JavascriptInterface
        fun importPlaylist(urlOrId: String, callbackId: String) {
            activeImportJob?.cancel()
            activeImportJob = uiScope.launch(Dispatchers.IO) {
                try {
                    val jsonStr = YouTubeEngine.importPlaylist(urlOrId)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $jsonStr, null)")
                } catch (_: CancellationException) {
                    // Superseded
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Playlist import failed")})")
                }
            }
        }

        @JavascriptInterface
        fun setAudioFx(preset: String, bassPercent: Int) {
            AudioFxBus.apply(preset, bassPercent)
        }

        @JavascriptInterface
        fun getAudioFx(): String = AudioFxBus.getStateJson()

        @JavascriptInterface
        fun search(query: String, musicOnly: Boolean, callbackId: String) {
            activeSearchJob?.cancel()
            activeSearchJob = uiScope.launch(Dispatchers.IO) {
                try {
                    val jsonArrayStr = YouTubeEngine.searchYouTube(query, musicOnly)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $jsonArrayStr, null)")
                } catch (_: CancellationException) {
                    // Superseded by newer search query
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Search failed")})")
                }
            }
        }

        @JavascriptInterface
        fun playTrack(trackJson: String) {
            try {
                val obj = JSONObject(trackJson)
                startTrackPlayback(obj, forceRefresh = false, resumeMs = 0L)
            } catch (e: Exception) {
                emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString(e.message ?: "Invalid track")})")
            }
        }

        @JavascriptInterface
        fun replayCurrent() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                ctrl.seekTo(0L)
                ctrl.play()
                pushPlaybackState(snap = true)
            }
        }

        @JavascriptInterface
        fun requestCoverTheme(trackId: String, coverUrl: String) {
            extractCoverThemeAsync(trackId, coverUrl)
        }

        @JavascriptInterface
        fun togglePlay() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                if (ctrl.isPlaying) ctrl.pause() else ctrl.play()
            }
        }

        @JavascriptInterface
        fun seekTo(seconds: Double) {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                ctrl.seekTo((seconds * 1000.0).toLong().coerceAtLeast(0L))
                pushPlaybackState(snap = true)
            }
        }

        @JavascriptInterface
        fun getDownloads(): String = YouTubeEngine.listDownloadsJson(this@MainActivity)

        @JavascriptInterface
        fun deleteDownload(videoId: String): Boolean {
            return YouTubeEngine.deleteDownload(this@MainActivity, videoId)
        }

        @JavascriptInterface
        fun downloadOpus(trackJson: String) {
            val obj = try {
                JSONObject(trackJson)
            } catch (e: Exception) {
                emitJs("window.__pulseOnError && window.__pulseOnError('Invalid track')")
                return
            }
            val id = YouTubeEngine.extractVideoId(obj.optString("id"))
            if (id.isBlank() || !activeDownloads.add(id)) return

            uiScope.launch(Dispatchers.IO) {
                try {
                    val saved = YouTubeEngine.downloadCompactAudio(
                        context = this@MainActivity,
                        videoIdOrUrl = id,
                        title = obj.optString("title", "Unknown"),
                        artist = obj.optString("artist", "YouTube"),
                        cover = obj.optString("cover", ""),
                        duration = obj.optDouble("duration", 0.0)
                    ) { pct ->
                        emitJs("window.__pulseOnDownloadProgress && window.__pulseOnDownloadProgress(${safeJsonString(id)}, $pct)")
                    }
                    emitJs("window.__pulseOnDownloadDone && window.__pulseOnDownloadDone($saved)")
                } catch (e: Exception) {
                    emitJs("window.__pulseOnDownloadFailed && window.__pulseOnDownloadFailed(${safeJsonString(id)}, ${safeJsonString(e.message ?: "Download failed")})")
                } finally {
                    activeDownloads.remove(id)
                }
            }
        }
    }

    override fun onDestroy() {
        PlaybackSkipBus.onSkipNext = null
        PlaybackSkipBus.onSkipPrev = null
        activePlayJob?.cancel()
        activeThemeJob?.cancel()
        activeSearchJob?.cancel()
        activeImportJob?.cancel()
        tickerHandler.removeCallbacks(progressTicker)
        uiScope.cancel()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        try {
            webView.removeJavascriptInterface("PulseNative")
            webView.stopLoading()
            webView.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
