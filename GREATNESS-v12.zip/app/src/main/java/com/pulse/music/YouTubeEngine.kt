package com.pulse.music

import android.content.Context
import android.os.Environment
import android.util.Log
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.YoutubeJavaScriptPlayerManager
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.File
import java.io.FileOutputStream

object YouTubeEngine {
    private const val TAG = "PulseYTEngine"
    private const val STREAM_CACHE_TTL_MS = 25L * 60L * 1000L // 25 minutes
    private const val MAX_STREAM_CACHE = 40

    private val indexLock = Any()
    private val cacheLock = Any()

    // Precompiled regexes avoid repeated allocations across search/playback
    private val V_PARAM_REGEX = Regex("[?&]v=([a-zA-Z0-9_-]{11})")
    private val SHORT_URL_REGEX = Regex("youtu\\.be/([a-zA-Z0-9_-]{11})")
    private val SHORTS_REGEX = Regex("/shorts/([a-zA-Z0-9_-]{11})")
    private val OFFLINE_EXTS = listOf("webm", "opus", "ogg", "m4a", "mp4")

    private data class CachedPlayback(
        val resolved: ResolvedPlayback,
        val cachedAtMs: Long
    )

    private val streamCache = object : LinkedHashMap<String, CachedPlayback>(24, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedPlayback>?): Boolean {
            return size > MAX_STREAM_CACHE
        }
    }

    @Volatile
    private var lastActiveMode: String = "NewPipe v0.27.1"

    data class StreamCandidate(
        val url: String,
        val label: String,
        val ext: String,
        val bitrateKbps: Int,
        val isHls: Boolean = false
    )

    data class ResolvedPlayback(
        val candidates: List<StreamCandidate>,
        val isOffline: Boolean,
        val healed: Boolean
    )

    fun getStatusJson(): String {
        return JSONObject().apply {
            put("engine", "NewPipeExtractor")
            put("version", "v0.27.1")
            put("activeMode", lastActiveMode)
        }.toString()
    }

    fun resetExtractorCache(): String {
        synchronized(cacheLock) { streamCache.clear() }
        return try {
            YoutubeJavaScriptPlayerManager.clearAllCaches()
            lastActiveMode = "Cache Cleared · Fresh Auth"
            "Cleared JS & stream caches"
        } catch (e: Exception) {
            "Reset warning: ${e.message}"
        }
    }

    fun invalidateStream(videoIdOrUrl: String) {
        val id = extractVideoId(videoIdOrUrl)
        synchronized(cacheLock) { streamCache.remove(id) }
    }

    fun extractVideoId(urlOrId: String): String {
        val trimmed = urlOrId.trim()
        if (!trimmed.contains("http") && !trimmed.contains("/")) return trimmed
        V_PARAM_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { return it }
        SHORT_URL_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { return it }
        SHORTS_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { return it }
        return trimmed
    }


    private val LIST_PARAM_REGEX = Regex("[?&]list=([a-zA-Z0-9_-]+)")

    fun normalizePlaylistUrl(urlOrId: String): String {
        val trimmed = urlOrId.trim()
        if (trimmed.isEmpty()) throw IllegalArgumentException("Paste a YouTube playlist URL")
        LIST_PARAM_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { listId ->
            return "https://www.youtube.com/playlist?list=$listId"
        }
        if (!trimmed.contains("http") && !trimmed.contains("/") && trimmed.length >= 10) {
            return "https://www.youtube.com/playlist?list=$trimmed"
        }
        return trimmed.replace("music.youtube.com", "www.youtube.com")
    }

    fun importPlaylist(urlOrId: String): String {
        val cleanUrl = normalizePlaylistUrl(urlOrId)
        val extractor = ServiceList.YouTube.getPlaylistExtractor(cleanUrl)
        extractor.fetchPage()

        val plName = try {
            extractor.name?.takeIf { it.isNotBlank() } ?: "YouTube Playlist"
        } catch (_: Exception) {
            "YouTube Playlist"
        }

        val collected = mutableListOf<StreamInfoItem>()
        var page = extractor.initialPage
        collected.addAll(page.items.filterIsInstance<StreamInfoItem>())

        var pagesFetched = 1
        while (page.hasNextPage() && collected.size < 200 && pagesFetched < 4) {
            val next: Page = page.nextPage ?: break
            try {
                page = extractor.getPage(next)
                collected.addAll(page.items.filterIsInstance<StreamInfoItem>())
                pagesFetched++
            } catch (e: Exception) {
                Log.w(TAG, "Stopped playlist pagination on page ${pagesFetched + 1}: ${e.message}")
                break
            }
        }

        val tracksArr = JSONArray()
        val seenIds = HashSet<String>()
        collected.take(200).forEach { item ->
            val id = extractVideoId(item.url)
            if (id.isNotBlank() && seenIds.add(id)) {
                val thumb = item.thumbnails
                    .maxByOrNull { it.width }?.url
                    ?.takeIf { it.isNotBlank() }
                    ?: "https://i.ytimg.com/vi/$id/hqdefault.jpg"
                tracksArr.put(JSONObject().apply {
                    put("id", id)
                    put("title", item.name ?: "Unknown Title")
                    put("artist", item.uploaderName ?: "YouTube")
                    put("duration", item.duration.coerceAtLeast(0L).toDouble())
                    put("cover", thumb)
                    put("source", "ytplaylist")
                })
            }
        }

        if (tracksArr.length() == 0) {
            throw IllegalStateException("No playable tracks found (check playlist is Public or Unlisted)")
        }

        return JSONObject().apply {
            put("name", plName)
            put("tracks", tracksArr)
        }.toString()
    }

    fun searchYouTube(query: String, musicOnly: Boolean): String {
        val clean = query.trim()
        if (clean.isEmpty()) return "[]"

        val service = ServiceList.YouTube
        val filters = if (musicOnly) {
            listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS)
        } else {
            emptyList()
        }

        val items = try {
            val qh = service.searchQHFactory.fromQuery(clean, filters, "")
            val info = SearchInfo.getInfo(service, qh)
            val list = info.relatedItems.filterIsInstance<StreamInfoItem>()
            if (list.isEmpty() && musicOnly) {
                val fallbackQh = service.searchQHFactory.fromQuery(clean, emptyList(), "")
                SearchInfo.getInfo(service, fallbackQh).relatedItems.filterIsInstance<StreamInfoItem>()
            } else {
                list
            }
        } catch (e: Exception) {
            if (musicOnly) {
                val fallbackQh = service.searchQHFactory.fromQuery(clean, emptyList(), "")
                SearchInfo.getInfo(service, fallbackQh).relatedItems.filterIsInstance<StreamInfoItem>()
            } else {
                throw e
            }
        }

        val out = JSONArray()
        items.take(25).forEach { item ->
            val id = extractVideoId(item.url)
            if (id.isNotBlank()) {
                val thumb = item.thumbnails
                    .maxByOrNull { it.width }?.url
                    ?.takeIf { it.isNotBlank() }
                    ?: "https://i.ytimg.com/vi/$id/hqdefault.jpg"

                val track = JSONObject().apply {
                    put("id", id)
                    put("title", item.name ?: "Unknown Title")
                    put("artist", item.uploaderName ?: "YouTube")
                    put("duration", item.duration.coerceAtLeast(0L).toDouble())
                    put("cover", thumb)
                    put("source", if (musicOnly) "ytmusic" else "youtube")
                }
                out.put(track)
            }
        }
        return out.toString()
    }

    fun resolvePlayback(
        context: Context,
        videoIdOrUrl: String,
        forceRefresh: Boolean = false
    ): ResolvedPlayback {
        val id = extractVideoId(videoIdOrUrl)

        findOfflineFile(context, id)?.let { local ->
            lastActiveMode = "Offline · ${local.extension.uppercase()}"
            return ResolvedPlayback(
                candidates = listOf(
                    StreamCandidate(
                        url = local.toURI().toString(),
                        label = "Offline ${local.extension.uppercase()}",
                        ext = local.extension,
                        bitrateKbps = 96
                    )
                ),
                isOffline = true,
                healed = false
            )
        }

        if (forceRefresh) {
            synchronized(cacheLock) { streamCache.remove(id) }
        } else {
            val now = System.currentTimeMillis()
            synchronized(cacheLock) {
                val cached = streamCache[id]
                if (cached != null && (now - cached.cachedAtMs) < STREAM_CACHE_TTL_MS) {
                    lastActiveMode = cached.resolved.candidates.first().label
                    return cached.resolved
                }
            }
        }

        val watchUrl = "https://www.youtube.com/watch?v=$id"
        var healed = false

        val streamInfo = try {
            if (forceRefresh) {
                YoutubeJavaScriptPlayerManager.clearAllCaches()
                healed = true
            }
            StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
        } catch (firstErr: Exception) {
            Log.w(TAG, "First extraction failed, clearing JS caches and retrying: ${firstErr.message}")
            YoutubeJavaScriptPlayerManager.clearAllCaches()
            healed = true
            StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
        }

        val candidates = buildOrderedCandidates(streamInfo)
        if (candidates.isEmpty()) {
            throw IllegalStateException("No playable audio streams returned by YouTube")
        }

        val result = ResolvedPlayback(candidates = candidates, isOffline = false, healed = healed)
        synchronized(cacheLock) {
            streamCache[id] = CachedPlayback(result, System.currentTimeMillis())
        }
        lastActiveMode = candidates.first().label
        return result
    }

    private fun parseResolutionHeight(res: String?): Int {
        if (res.isNullOrBlank()) return Int.MAX_VALUE
        var value = 0
        var seenDigit = false
        for (ch in res) {
            if (ch in '0'..'9') {
                value = value * 10 + (ch - '0')
                seenDigit = true
            } else if (seenDigit) {
                break
            }
        }
        return if (seenDigit && value > 0) value else Int.MAX_VALUE
    }

    private fun buildOrderedCandidates(info: StreamInfo): List<StreamCandidate> {
        val list = mutableListOf<StreamCandidate>()
        val progressiveAudio = info.audioStreams
            .filter { !it.content.isNullOrBlank() && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }

        val opusStreams = progressiveAudio
            .filter { it.format == MediaFormat.WEBMA_OPUS || it.format == MediaFormat.OPUS }
            .sortedBy { kotlin.math.abs((it.averageBitrate.takeIf { b -> b > 0 } ?: 128) - 128) }
        opusStreams.forEach { s ->
            val br = s.averageBitrate.takeIf { it > 0 } ?: 128
            list.add(StreamCandidate(s.content, "Opus ${br}k", "webm", br))
        }

        val m4aStreams = progressiveAudio
            .filter { it.format == MediaFormat.M4A }
            .sortedByDescending { it.averageBitrate }
        m4aStreams.forEach { s ->
            val br = s.averageBitrate.takeIf { it > 0 } ?: 128
            list.add(StreamCandidate(s.content, "M4A ${br}k", "m4a", br))
        }

        progressiveAudio
            .filter { s -> list.none { it.url == s.content } }
            .sortedByDescending { it.averageBitrate }
            .forEach { s ->
                val br = s.averageBitrate.takeIf { it > 0 } ?: 96
                val ext = s.format?.suffix ?: "webm"
                list.add(StreamCandidate(s.content, "${ext.uppercase()} ${br}k", ext, br))
            }

        val hlsUrl = info.hlsUrl
        if (!hlsUrl.isNullOrBlank()) {
            list.add(StreamCandidate(hlsUrl, "HLS Adaptive", "m3u8", 128, isHls = true))
        }

        // Fixed numeric resolution sorting so 144p/360p is picked instead of 1080p
        info.videoStreams
            .filter { !it.content.isNullOrBlank() && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .sortedBy { parseResolutionHeight(it.resolution) }
            .firstOrNull()
            ?.let { mux ->
                list.add(StreamCandidate(mux.content, "Fallback Audio", "mp4", 128))
            }

        return list.distinctBy { it.url }
    }

    fun getOfflineDir(context: Context): File {
        val base = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
        val dir = File(base, "PulseOpus")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getIndexFile(context: Context): File = File(getOfflineDir(context), "library.json")

    fun findOfflineFile(context: Context, videoId: String): File? {
        val dir = getOfflineDir(context)
        for (ext in OFFLINE_EXTS) {
            val f = File(dir, "$videoId.$ext")
            if (f.exists() && f.length() > 1024L) return f
        }
        return null
    }

    fun listDownloadsJson(context: Context): String {
        return synchronized(indexLock) {
            val indexFile = getIndexFile(context)
            if (!indexFile.exists()) return@synchronized "[]"
            try {
                val raw = JSONArray(indexFile.readText())
                val valid = JSONArray()
                var pruned = false
                for (i in 0 until raw.length()) {
                    val obj = raw.getJSONObject(i)
                    val f = File(obj.optString("filePath"))
                    if (f.exists() && f.length() > 1024L) {
                        obj.put("sizeKb", f.length() / 1024L)
                        valid.put(obj)
                    } else {
                        pruned = true
                    }
                }
                if (pruned) {
                    try { indexFile.writeText(valid.toString()) } catch (_: Exception) {}
                }
                valid.toString()
            } catch (_: Exception) {
                "[]"
            }
        }
    }

    fun deleteDownload(context: Context, videoId: String): Boolean {
        return synchronized(indexLock) {
            val id = extractVideoId(videoId)
            val dir = getOfflineDir(context)
            var deleted = false
            for (ext in OFFLINE_EXTS) {
                val f = File(dir, "$id.$ext")
                if (f.exists() && f.delete()) deleted = true
            }
            val indexFile = getIndexFile(context)
            if (indexFile.exists()) {
                try {
                    val arr = JSONArray(indexFile.readText())
                    val updated = JSONArray()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        if (item.optString("id") != id) updated.put(item)
                    }
                    indexFile.writeText(updated.toString())
                } catch (_: Exception) {
                }
            }
            deleted
        }
    }

    fun downloadCompactAudio(
        context: Context,
        videoIdOrUrl: String,
        title: String,
        artist: String,
        cover: String,
        duration: Double,
        onProgress: (Int) -> Unit
    ): JSONObject {
        val id = extractVideoId(videoIdOrUrl)
        val resolved = resolvePlayback(context, id, forceRefresh = false)

        val target = resolved.candidates
            .filter { !it.isHls && it.url.startsWith("http") }
            .sortedWith(
                compareBy<StreamCandidate>(
                    { if (it.ext == "webm" || it.ext == "opus") 0 else 1 },
                    { kotlin.math.abs(it.bitrateKbps - 96) }
                )
            )
            .firstOrNull()
            ?: throw IllegalStateException("No direct downloadable audio stream available for this track")

        val dir = getOfflineDir(context)
        val tmpFile = File(dir, "$id.${target.ext}.part")
        val finalFile = File(dir, "$id.${target.ext}")

        val request = Request.Builder()
            .url(target.url)
            .header("User-Agent", PulseDownloader.USER_AGENT)
            .build()

        try {
            PulseDownloader.httpClient.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) {
                    if (resp.code == 403 || resp.code == 410) invalidateStream(id)
                    throw IllegalStateException("Download HTTP ${resp.code}")
                }
                val body = resp.body ?: throw IllegalStateException("Empty audio response")
                val totalBytes = body.contentLength()
                var copied = 0L
                var lastReported = -1

                body.byteStream().use { input ->
                    FileOutputStream(tmpFile).use { output ->
                        val buffer = ByteArray(32 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            copied += read
                            if (totalBytes > 0L) {
                                val pct = ((copied * 100L) / totalBytes).toInt().coerceIn(0, 99)
                                if (pct >= lastReported + 3) {
                                    lastReported = pct
                                    onProgress(pct)
                                }
                            }
                        }
                        output.flush()
                    }
                }
            }
        } catch (e: Exception) {
            if (tmpFile.exists()) tmpFile.delete()
            throw e
        }

        if (finalFile.exists()) finalFile.delete()
        if (!tmpFile.renameTo(finalFile)) {
            tmpFile.copyTo(finalFile, overwrite = true)
            tmpFile.delete()
        }
        onProgress(100)

        val codecLabel = if (target.ext == "webm" || target.ext == "opus") {
            "OPUS ${target.bitrateKbps}k"
        } else {
            "${target.ext.uppercase()} ${target.bitrateKbps}k"
        }

        val entry = JSONObject().apply {
            put("id", id)
            put("title", title)
            put("artist", artist)
            put("cover", cover)
            put("duration", duration)
            put("codec", codecLabel)
            put("sizeKb", finalFile.length() / 1024L)
            put("filePath", finalFile.absolutePath)
            put("source", "offline")
        }

        saveToIndex(context, entry)
        return entry
    }

    private fun saveToIndex(context: Context, entry: JSONObject) {
        synchronized(indexLock) {
            val indexFile = getIndexFile(context)
            val arr = if (indexFile.exists()) {
                try { JSONArray(indexFile.readText()) } catch (_: Exception) { JSONArray() }
            } else JSONArray()

            val updated = JSONArray()
            val id = entry.getString("id")
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                if (item.optString("id") != id) updated.put(item)
            }
            updated.put(entry)
            indexFile.writeText(updated.toString())
        }
    }
}
