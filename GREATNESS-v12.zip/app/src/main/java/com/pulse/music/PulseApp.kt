package com.pulse.music

import android.app.Application
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.Localization

class PulseApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NewPipe.init(PulseDownloader.instance, Localization.DEFAULT)
    }
}
